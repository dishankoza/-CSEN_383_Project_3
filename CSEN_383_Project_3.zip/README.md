ReadMe File
===========
cd src

Compile:
	$ gcc *.c -lpthread -o project_3

Execute:
	$ ./project_3 num
		where, num is no of customers per queue

Example:
	To simulate ticket sell with 10 customers arriving at random time for every seller queue
	$ ./project_3 10 

All the output is collected in the [output.txt](./output.txt)